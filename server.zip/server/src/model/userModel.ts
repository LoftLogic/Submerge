import { DataTypes, Model, Optional } from 'sequelize';
import { sequelize } from '../old/connection';
import { Gender, Sexuality, Ethnicity } from '../types';

